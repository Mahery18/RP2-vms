package com.example.vmsproject;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.*;
import jakarta.mail.internet.*;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DemandeFormController {

    @FXML private ComboBox<String> clientCombo;
    @FXML private TextField quantiteField;
    @FXML private TextField valeurField;
    @FXML private DatePicker validityPicker;
    @FXML private CheckBox fixedExpiryCheck;
    @FXML private Button chooseFileButton;
    @FXML private Label fileLabel;
    @FXML private TextField clientEmailField;

    private File invoiceFile;
    private DemandesController parentController;

    // =========================
    // CONFIGURATION GMAIL
    // =========================
    private final String SMTP_HOST = "smtp.gmail.com";
    private final int SMTP_PORT = 587;
    private final String SMTP_USER = "maheryifalianaras@gmail.com";
    private final String SMTP_PASS = "jxkjtdcrpubwtolr";
    private final String FROM_EMAIL = "maheryifalianaras@gmail.com";
    private final String TO_EMAIL = "maheryifalianaras@gmail.com";

    public DemandeFormController() {
        Logger.getLogger("jakarta.mail").setLevel(Level.SEVERE);
        Logger.getLogger("jakarta.activation").setLevel(Level.SEVERE);
    }

    // =========================
    // INITIALISATION
    // =========================
    @FXML
    public void initialize() {
        loadClients();
        setupClientSelection();
    }

    // =========================
    // CHARGER CLIENTS
    // =========================
    private void loadClients() {
        String sql = "SELECT name FROM client";

        try (
                Connection conn = new DatabaseConnection().getConnection();
                PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery()
        ) {
            clientCombo.getItems().clear();

            while (rs.next()) {
                clientCombo.getItems().add(rs.getString("name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Erreur chargement clients", "Impossible de charger la liste des clients.");
        }
    }

    // =========================
    // SELECTION CLIENT
    // =========================
    private void setupClientSelection() {
        clientCombo.setOnAction(event -> {
            String selectedClient = clientCombo.getValue();
            if (selectedClient != null && !selectedClient.isBlank()) {
                loadClientEmail(selectedClient);
            }
        });
    }

    // =========================
    // CHARGER EMAIL CLIENT
    // =========================
    private void loadClientEmail(String clientName) {
        String sql = "SELECT email FROM client WHERE name = ?";

        try (
                Connection conn = new DatabaseConnection().getConnection();
                PreparedStatement pst = conn.prepareStatement(sql)
        ) {
            pst.setString(1, clientName);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    clientEmailField.setText(rs.getString("email"));
                } else {
                    clientEmailField.clear();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            showError("Erreur chargement email", "Impossible de charger l'email du client.");
        }
    }

    public void setParentController(DemandesController parent) {
        this.parentController = parent;
    }

    // =========================
    // CHOISIR FICHIER PDF
    // =========================
    @FXML
    private void chooseFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choisir le fichier invoice");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );

        invoiceFile = fileChooser.showOpenDialog(chooseFileButton.getScene().getWindow());

        if (invoiceFile != null) {
            fileLabel.setText(invoiceFile.getName());
        } else {
            fileLabel.setText("Aucun fichier choisi");
        }
    }

    // =========================
    // ENREGISTRER DEMANDE
    // =========================
    @FXML
    public void saveDemande() {
        try {
            // Validation simple
            if (clientCombo.getValue() == null || clientCombo.getValue().isBlank()) {
                showWarning("Validation", "Veuillez sélectionner un client.");
                return;
            }

            if (quantiteField.getText() == null || quantiteField.getText().isBlank()) {
                showWarning("Validation", "Veuillez saisir la quantité.");
                return;
            }

            if (valeurField.getText() == null || valeurField.getText().isBlank()) {
                showWarning("Validation", "Veuillez saisir la valeur unitaire.");
                return;
            }

            if (validityPicker.getValue() == null) {
                showWarning("Validation", "Veuillez choisir une date de validité.");
                return;
            }

            String client = clientCombo.getValue();
            String clientEmail = clientEmailField.getText();

            int quantite = Integer.parseInt(quantiteField.getText().trim());
            double valeur = Double.parseDouble(valeurField.getText().trim());
            double amount = quantite * valeur;
            LocalDate validity = validityPicker.getValue();

            String reference = "VR" + System.currentTimeMillis();

            // ENREGISTRER EN BASE
            String sql = """
                    INSERT INTO demande 
                    (reference, client, quantite, valeur_unitaire, amount, validity_date, fixed_expiry, recorded_by, email)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """;

            try (
                    Connection conn = new DatabaseConnection().getConnection();
                    PreparedStatement pst = conn.prepareStatement(sql)
            ) {
                pst.setString(1, reference);
                pst.setString(2, client);
                pst.setInt(3, quantite);
                pst.setDouble(4, valeur);
                pst.setDouble(5, amount);
                pst.setDate(6, java.sql.Date.valueOf(validity));
                pst.setBoolean(7, fixedExpiryCheck.isSelected());
                pst.setString(8, "initiator");
                pst.setString(9, clientEmail);

                pst.executeUpdate();
            }

            // METTRE A JOUR LE TABLEAU
            if (parentController != null) {
                parentController.addDemande(new Demande(
                        reference,
                        LocalDate.now(),
                        client,
                        quantite,
                        amount,
                        validity,
                        fixedExpiryCheck.isSelected(),
                        "Pending",
                        "initiator",
                        "",
                        "",
                        clientEmail
                ));
            }

            // ENVOI EMAIL
            sendEmailWithAttachment(invoiceFile, reference, client, clientEmail, quantite, valeur, amount, validity);

            showInfo("Succès", "Demande enregistrée et email envoyé.");
            resetForm();

        } catch (NumberFormatException e) {
            e.printStackTrace();
            showError("Erreur de saisie", "Quantité ou valeur invalide.");
        } catch (MessagingException e) {
            e.printStackTrace();
            showError("Erreur email", "La demande est enregistrée, mais l'email n'a pas pu être envoyé.\n\n" + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            showError("Erreur", "Erreur lors de l'enregistrement de la demande.\n\n" + e.getMessage());
        }
    }

    // =========================
    // RESET FORMULAIRE
    // =========================
    private void resetForm() {
        clientCombo.setValue(null);
        clientEmailField.clear();
        quantiteField.clear();
        valeurField.clear();
        validityPicker.setValue(null);
        fixedExpiryCheck.setSelected(false);
        invoiceFile = null;
        fileLabel.setText("Aucun fichier choisi");
    }

    // =========================
    // ENVOI EMAIL
    // =========================
    private void sendEmailWithAttachment(
            File file,
            String reference,
            String client,
            String clientEmail,
            int quantite,
            double valeur,
            double amount,
            LocalDate validity
    ) throws MessagingException {

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", String.valueOf(SMTP_PORT));
        props.put("mail.debug", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_USER, SMTP_PASS);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(TO_EMAIL));
        message.setSubject("Nouvelle demande à approuver - " + reference);

        String htmlContent =
                "<h2>Nouvelle demande créée</h2>"
                        + "<p><b>Référence :</b> " + reference + "</p>"
                        + "<p><b>Client :</b> " + client + "</p>"
                        + "<p><b>Email client :</b> " + (clientEmail == null || clientEmail.isBlank() ? "-" : clientEmail) + "</p>"
                        + "<p><b>Quantité :</b> " + quantite + "</p>"
                        + "<p><b>Valeur unitaire :</b> " + valeur + "</p>"
                        + "<p><b>Montant total :</b> " + amount + "</p>"
                        + "<p><b>Date de validité :</b> " + validity + "</p>"
                        + "<p><b>Fixed expiry :</b> " + (fixedExpiryCheck.isSelected() ? "Oui" : "Non") + "</p>"
                        + "<br>"
                        + "<p>Veuillez vérifier et approuver cette demande.</p>";

        MimeBodyPart textPart = new MimeBodyPart();
        textPart.setContent(htmlContent, "text/html; charset=UTF-8");

        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(textPart);

        // Pièce jointe seulement si un fichier a été choisi
        if (file != null) {
            MimeBodyPart attachmentPart = new MimeBodyPart();
            DataSource source = new FileDataSource(file);
            attachmentPart.setDataHandler(new DataHandler(source));
            attachmentPart.setFileName(file.getName());
            multipart.addBodyPart(attachmentPart);
        }

        message.setContent(multipart);

        Transport.send(message);
        System.out.println("Email envoyé avec succès à : " + TO_EMAIL);
    }

    // =========================
    // ALERTES
    // =========================
    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.show();
    }

    private void showWarning(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.show();
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.show();
    }
}