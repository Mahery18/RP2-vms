package com.example.vmsproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.io.IOException;

public class DemandesDashboardController {

    @FXML private StackPane mainContent;

    private DemandesController demandesController;
    private DemandeFormController demandeFormController;

    @FXML
    public void initialize() {
        showTableView(); // Affiche la table au démarrage
    }

    @FXML
    public void showTableView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/demandes_list.fxml"));
            Node node = loader.load();
            demandesController = loader.getController();

            mainContent.getChildren().clear();
            mainContent.getChildren().add(node);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void showFormView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/demande_form.fxml"));
            Node node = loader.load();
            demandeFormController = loader.getController();

            // Relier le formulaire au tableau pour actualiser la TableView
            if (demandesController != null) {
                demandeFormController.setParentController(demandesController);
            }

            mainContent.getChildren().clear();
            mainContent.getChildren().add(node);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void showApproveView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/approuve.fxml"));
            Node node = loader.load();

            mainContent.getChildren().clear();
            mainContent.getChildren().add(node);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void goBack() {
        try {
            Stage stage = (Stage) mainContent.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/home.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
