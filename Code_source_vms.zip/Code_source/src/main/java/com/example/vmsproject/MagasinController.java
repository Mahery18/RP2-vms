package com.example.vmsproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class MagasinController {

    // ---- Pour la rédemption ----
    @FXML private TextField voucherCodeField;
    @FXML private ComboBox<Magasin> magasinComboBox;
    @FXML private Button redeemButton;
    @FXML private TableView<Voucher> voucherTable;
    @FXML private TableColumn<Voucher, String> colVoucherCode;

    private ObservableList<Voucher> voucherList = FXCollections.observableArrayList();

    private User currentUser;
    @FXML
    private AnchorPane contentPane; // ajoute ceci en haut de ton controller

    // ---- Pour le CRUD Magasins ----
    @FXML private TableView<Magasin> tableMagasins;
    @FXML private TableColumn<Magasin, Integer> colMagasinId;
    @FXML private TableColumn<Magasin, String> colMagasinName;
    @FXML
    private TableColumn<Magasin, Void> colMagasinActions;


    private ObservableList<Magasin> magasinList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // ---- Vouchers ----
        colVoucherCode.setCellValueFactory(new PropertyValueFactory<>("voucherCode"));
        loadUnusedVouchers();
        loadMagasins();

        // ---- CRUD Magasins ----
        colMagasinId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colMagasinName.setCellValueFactory(new PropertyValueFactory<>("name"));
        addButtonToTable();
        loadMagasinTable();
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
        if (user != null) {
            System.out.println("MagasinController → Utilisateur connecté : " + user.getUsername());
        } else {
            System.out.println("⚠ Aucun utilisateur reçu !");
        }
    }

    // -------------------- VOUCHERS --------------------
    private void loadUnusedVouchers() {
        try (Connection conn = new DatabaseConnection().getConnection()) {
            voucherList.clear();
            String sql = "SELECT * FROM voucher WHERE status = 'Unused'";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Voucher v = new Voucher(
                        rs.getString("voucher_code"),
                        rs.getString("demande_reference"),
                        rs.getString("client"),
                        rs.getDouble("amount"),
                        rs.getDate("validity_date").toLocalDate(),
                        rs.getString("status"),
                        rs.getString("qr_path"),
                        rs.getString("pdf_path")
                );
                voucherList.add(v);
            }
            voucherTable.setItems(voucherList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadMagasins() {
        try (Connection conn = new DatabaseConnection().getConnection()) {
            magasinList.clear();
            String sql = "SELECT id, name FROM magasins"; // ⚡ table correcte
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                magasinList.add(new Magasin(rs.getInt("id"), rs.getString("name")));
            }
            magasinComboBox.setItems(magasinList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void redeemVoucher() {
        if (currentUser == null) {
            new Alert(Alert.AlertType.ERROR, "Aucun utilisateur connecté").show();
            return;
        }

        String code = voucherCodeField.getText();
        Magasin selectedMagasin = magasinComboBox.getValue();
        if (code.isEmpty() || selectedMagasin == null) {
            new Alert(Alert.AlertType.WARNING, "Veuillez entrer le code et sélectionner un magasin").show();
            return;
        }

        try (Connection conn = new DatabaseConnection().getConnection()) {

            String checkSql = "SELECT id, status FROM voucher WHERE voucher_code = ?";
            PreparedStatement pstCheck = conn.prepareStatement(checkSql);
            pstCheck.setString(1, code);
            ResultSet rs = pstCheck.executeQuery();

            if (rs.next()) {
                int voucherId = rs.getInt("id");
                String status = rs.getString("status");

                if (!status.equalsIgnoreCase("Unused")) {
                    new Alert(Alert.AlertType.ERROR, "Ce voucher a déjà été utilisé !").show();
                    return;
                }

                String updateVoucher = "UPDATE voucher SET status = 'Redeemed' WHERE id = ?";
                PreparedStatement pstUpdate = conn.prepareStatement(updateVoucher);
                pstUpdate.setInt(1, voucherId);
                pstUpdate.executeUpdate();

                String insertRedemption =
                        "INSERT INTO redemptions(voucher_id, magasin_id, user_id) VALUES (?,?,?)";

                PreparedStatement pstRedemption = conn.prepareStatement(insertRedemption);
                pstRedemption.setInt(1, voucherId);
                pstRedemption.setInt(2, selectedMagasin.getId());
                pstRedemption.setInt(3, currentUser.getId());
                pstRedemption.executeUpdate();

                new Alert(Alert.AlertType.INFORMATION, "Voucher " + code + " rédimé avec succès !").show();
                loadUnusedVouchers();

            } else {
                new Alert(Alert.AlertType.ERROR, "Voucher introuvable !").show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Erreur lors de la rédemption").show();
        }
    }

    // -------------------- CRUD MAGASINS --------------------
    private void loadMagasinTable() {
        magasinList.clear();
        try (Connection conn = new DatabaseConnection().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM magasins")) {

            while (rs.next()) {
                magasinList.add(new Magasin(rs.getInt("id"), rs.getString("name")));
            }
            tableMagasins.setItems(magasinList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addMagasin() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Ajouter Magasin");
        dialog.setHeaderText(null);
        dialog.setContentText("Nom du magasin :");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(name -> {
            try (Connection conn = new DatabaseConnection().getConnection()) {
                String query = "INSERT INTO magasins(name) VALUES (?)";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setString(1, name);
                pst.executeUpdate();
                loadMagasinTable();
                loadMagasins(); // mise à jour ComboBox
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    private void addButtonToTable() {
        Callback<TableColumn<Magasin, Void>, TableCell<Magasin, Void>> cellFactory = param -> new TableCell<>() {
            private final Button btnEdit = new Button("Modifier");
            private final Button btnDelete = new Button("Supprimer");
            private final HBox pane = new HBox(btnEdit, btnDelete);

            {
                pane.setSpacing(10);

                btnEdit.setOnAction(event -> {
                    Magasin m = getTableView().getItems().get(getIndex());
                    updateMagasin(m);
                });

                btnDelete.setOnAction(event -> {
                    Magasin m = getTableView().getItems().get(getIndex());
                    deleteMagasin(m);
                });
            }

            @Override
            public void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) setGraphic(null);
                else setGraphic(pane);
            }
        };

        colMagasinActions.setCellFactory(cellFactory);
    }

    private void updateMagasin(Magasin m) {
        TextInputDialog dialog = new TextInputDialog(m.getName());
        dialog.setTitle("Modifier Magasin");
        dialog.setHeaderText(null);
        dialog.setContentText("Nom du magasin :");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(name -> {
            try (Connection conn = new DatabaseConnection().getConnection()) {
                String query = "UPDATE magasins SET name = ? WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setString(1, name);
                pst.setInt(2, m.getId());
                pst.executeUpdate();
                loadMagasinTable();
                loadMagasins(); // mise à jour ComboBox
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    private void deleteMagasin(Magasin m) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Supprimer Magasin");
        alert.setHeaderText(null);
        alert.setContentText("Voulez-vous vraiment supprimer " + m.getName() + " ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = new DatabaseConnection().getConnection()) {
                String query = "DELETE FROM magasins WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setInt(1, m.getId());
                pst.executeUpdate();
                loadMagasinTable();
                loadMagasins();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML private AnchorPane redeemPane;
    @FXML private AnchorPane crudPane;

    @FXML
    private void showRedeemPane() {
        redeemPane.setVisible(true);
        crudPane.setVisible(false);
    }

    @FXML
    private void showCrudPane() {
        redeemPane.setVisible(false);
        crudPane.setVisible(true);
    }

    @FXML
    private void goBack() {
        try {
            Stage stage = (Stage) contentPane.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/home.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
