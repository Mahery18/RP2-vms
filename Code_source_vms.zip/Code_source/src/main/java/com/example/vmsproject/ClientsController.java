package com.example.vmsproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class ClientsController {

    @FXML private TableView<Client> tableClients;
    @FXML private TableColumn<Client, Integer> colId;
    @FXML private TableColumn<Client, String> colName;
    @FXML private TableColumn<Client, String> colEmail;
    @FXML private TableColumn<Client, String> colPhone;
    @FXML private TableColumn<Client, String> colAddress;
    @FXML private TableColumn<Client, Void> colActions;

    private ObservableList<Client> clientsList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));

        addButtonToTable();
        loadClients();
    }

    public void loadClients() {
        clientsList.clear();
        DatabaseConnection db = new DatabaseConnection();
        try (Connection conn = db.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM client")) {

            while (rs.next()) {
                clientsList.add(new Client(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address")
                ));
            }
            tableClients.setItems(clientsList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addClient() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Ajouter client");
        dialog.setHeaderText(null);
        dialog.setContentText("Nom du client:");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent() && !result.get().isEmpty()) {
            String name = result.get();

            TextInputDialog emailDialog = new TextInputDialog();
            emailDialog.setTitle("Ajouter client");
            emailDialog.setHeaderText(null);
            emailDialog.setContentText("Email:");
            Optional<String> emailResult = emailDialog.showAndWait();

            if (emailResult.isPresent() && !emailResult.get().isEmpty()) {
                String email = emailResult.get();

                DatabaseConnection db = new DatabaseConnection();
                try (Connection conn = db.getConnection()) {
                    String query = "INSERT INTO client (name, email) VALUES (?, ?)";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, name);
                    pst.setString(2, email);
                    pst.executeUpdate();
                    loadClients();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void addButtonToTable() {
        Callback<TableColumn<Client, Void>, TableCell<Client, Void>> cellFactory = param -> new TableCell<>() {
            private final Button btnEdit = new Button("Modifier");
            private final Button btnDelete = new Button("Supprimer");
            private final HBox pane = new HBox(btnEdit, btnDelete);

            {
                pane.setSpacing(10);

                btnEdit.setOnAction(event -> {
                    Client client = getTableView().getItems().get(getIndex());
                    updateClient(client);
                });

                btnDelete.setOnAction(event -> {
                    Client client = getTableView().getItems().get(getIndex());
                    deleteClient(client);
                });
            }

            @Override
            public void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(pane);
                }
            }
        };

        colActions.setCellFactory(cellFactory);
    }

    private void updateClient(Client client) {
        Dialog<Client> dialog = new Dialog<>();
        dialog.setTitle("Modifier client");

        ButtonType okButtonType = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButtonType, ButtonType.CANCEL);

        TextField nameField = new TextField(client.getName());
        TextField emailField = new TextField(client.getEmail());
        TextField phoneField = new TextField(client.getPhone());
        TextField addressField = new TextField(client.getAddress());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Nom:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Email:"), 0, 1);
        grid.add(emailField, 1, 1);
        grid.add(new Label("Téléphone:"), 0, 2);
        grid.add(phoneField, 1, 2);
        grid.add(new Label("Adresse:"), 0, 3);
        grid.add(addressField, 1, 3);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButtonType) {
                return new Client(client.getId(), nameField.getText(), emailField.getText(), phoneField.getText(), addressField.getText());
            }
            return null;
        });

        Optional<Client> result = dialog.showAndWait();

        result.ifPresent(updatedClient -> {
            DatabaseConnection db = new DatabaseConnection();
            try (Connection conn = db.getConnection()) {
                String query = "UPDATE client SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setString(1, updatedClient.getName());
                pst.setString(2, updatedClient.getEmail());
                pst.setString(3, updatedClient.getPhone());
                pst.setString(4, updatedClient.getAddress());
                pst.setInt(5, updatedClient.getId());
                pst.executeUpdate();
                loadClients();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    private void deleteClient(Client client) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Supprimer client");
        alert.setHeaderText(null);
        alert.setContentText("Voulez-vous vraiment supprimer " + client.getName() + " ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            DatabaseConnection db = new DatabaseConnection();
            try (Connection conn = db.getConnection()) {
                String query = "DELETE FROM client WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setInt(1, client.getId());
                pst.executeUpdate();
                loadClients();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void goBack() {
        try {
            Stage stage = (Stage) tableClients.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/home.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
