package com.example.vmsproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import java.io.IOException;

public class DashboardController {


    @FXML
    private VBox mainContainer;

    @FXML
    private void handleLogin(ActionEvent event) {
        try {
            Parent loginPane = FXMLLoader.load(getClass().getResource("/login.fxml"));
            mainContainer.getChildren().clear();
            mainContainer.getChildren().add(loginPane);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
