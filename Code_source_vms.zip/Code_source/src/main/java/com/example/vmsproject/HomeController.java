package com.example.vmsproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class HomeController {

    @FXML
    private Label timeLabel;

    @FXML
    private Label dateLabel;

    @FXML
    private ImageView logoutIcon;

    @FXML
    private Label usernameLabel;

    // ==== CARTES DU DASHBOARD ====
    @FXML
    private Pane cardUsers;

    @FXML
    private Pane cardClients;

    @FXML
    private Pane cardMagasin;

    @FXML
    private Pane cardDemandes;

    @FXML
    private Pane cardVoucher;

    private String userRole;

    private User currentUser;

    public void setCurrentUser(User user) {
        this.currentUser = user;
        System.out.println("Utilisateur connecté : " + user.getUsername());
    }


    // ------------------------------------------------------

    @FXML
    public void initialize() {
        timeLabel.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        dateLabel.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")));
    }

    // ------------------------------------------------------

    public void setUserInfo(String username, String role) {
        usernameLabel.setText("Hello " + username);
        this.userRole = role == null ? "" : role.toLowerCase().trim();
        applyRolePermissions();
    }

    // ------------------------------------------------------

    private void applyRolePermissions() {

        if (userRole.equals("superadmin")) {
            return; // tous les accès
        }

        switch (userRole) {

            case "admin":
                cardVoucher.setDisable(true);
                cardUsers.setDisable(true);
                cardClients.setDisable(true);
                break;

            case "initiator":
                cardUsers.setDisable(true);
                cardDemandes.setDisable(true);

                break;

            case "approver":
                cardDemandes.setDisable(true);
                cardVoucher.setDisable(true);
                break;

            case "magasin":
                cardMagasin.setDisable(true);
                break;

            default:
                System.out.println("⚠ Rôle inconnu : " + userRole);
                break;
        }
    }

    // ------------------------------------------------------
    //                      LOGOUT
    // ------------------------------------------------------

    public void logout() {
        try {
            Stage stage = (Stage) logoutIcon.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/login.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
            stage.setTitle("Connexion");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ------------------------------------------------------
    //                      NAVIGATION
    // ------------------------------------------------------

    public void openDemandes() {
        try {
            Stage stage = (Stage) logoutIcon.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/demandes_dashboard.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
            stage.setTitle("Gestion Demandes");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openUsers() {
        try {
            Stage stage = (Stage) logoutIcon.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/users.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
            stage.setTitle("Gestion utilisateurs");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openMagasin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/magasin.fxml"));
            Pane root = loader.load();  // 1️⃣ Charger la vue
            MagasinController magasinCtrl = loader.getController(); // 2️⃣ Récupérer le controller
            magasinCtrl.setCurrentUser(this.currentUser);  // 3️⃣ Transmettre l'utilisateur

            Stage stage = (Stage) logoutIcon.getScene().getWindow();
            stage.setScene(new Scene(root)); // 4️⃣ Mettre la scène
            stage.setMaximized(true);
            stage.setTitle("Gestion magasins");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void openClients() {
        try {
            Stage stage = (Stage) logoutIcon.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/clients.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
            stage.setTitle("Gestion clients");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void openVoucher() {
        try {
            Stage stage = (Stage) logoutIcon.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/voucher.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
            stage.setTitle("Gestion des voucher");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
