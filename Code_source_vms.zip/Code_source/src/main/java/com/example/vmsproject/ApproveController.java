package com.example.vmsproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.util.Properties;

import jakarta.mail.*;
import jakarta.mail.internet.*;

public class ApproveController {

    @FXML private TableView<Demande> tablePending;
    @FXML private TableColumn<Demande, String> colReference;
    @FXML private TableColumn<Demande, String> colClient;
    @FXML private TableColumn<Demande, Double> colAmount;
    @FXML private TableColumn<Demande, String> colStatus;
    @FXML private TableColumn<Demande, Void> colAction;

    private ObservableList<Demande> pendingList = FXCollections.observableArrayList();

    // =========================
    // CONFIGURATION GMAIL
    // =========================
    private final String SMTP_HOST = "smtp.gmail.com";
    private final int SMTP_PORT = 587;
    private final String SMTP_USER = "maheryifalianaras@gmail.com";
    private final String SMTP_PASS = "jxkjtdcrpubwtolr";
    private final String FROM_EMAIL = "maheryifalianaras@gmail.com";

    @FXML
    public void initialize() {
        colReference.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colClient.setCellValueFactory(new PropertyValueFactory<>("client"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        addApproveButtonToTable();
        loadPendingDemandes();
    }

    private void loadPendingDemandes() {
        pendingList.clear();
        DatabaseConnection db = new DatabaseConnection();

        try (Connection conn = db.getConnection();
             PreparedStatement pst = conn.prepareStatement("SELECT * FROM demande WHERE status = 'Pending'");
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                pendingList.add(new Demande(
                        rs.getString("reference"),
                        rs.getDate("date_created").toLocalDate(),
                        rs.getString("client"),
                        rs.getInt("quantite"),
                        rs.getDouble("amount"),
                        rs.getDate("validity_date") != null ? rs.getDate("validity_date").toLocalDate() : null,
                        rs.getBoolean("fixed_expiry"),
                        rs.getString("status"),
                        rs.getString("recorded_by"),
                        rs.getString("approved_by"),
                        rs.getString("payment_remarks"),
                        rs.getString("email")
                ));
            }

            tablePending.setItems(pendingList);

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Erreur", "Impossible de charger les demandes en attente.");
        }
    }

    private void addApproveButtonToTable() {
        colAction.setCellFactory(param -> new TableCell<>() {
            private final Button approveBtn = new Button("Approuver");

            {
                approveBtn.setOnAction(event -> {
                    Demande demande = getTableView().getItems().get(getIndex());
                    approveDemande(demande);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(approveBtn);
                }
            }
        });
    }

    private void approveDemande(Demande demande) {
        DatabaseConnection db = new DatabaseConnection();

        try (Connection conn = db.getConnection();
             PreparedStatement pst = conn.prepareStatement(
                     "UPDATE demande SET status = 'Approved', approved_by = ? WHERE reference = ?")) {

            pst.setString(1, "approver");
            pst.setString(2, demande.getReference());
            pst.executeUpdate();

            demande.setStatus("Approved");
            demande.setApprovedBy("approver");

            // envoi email au client
            sendApprovalEmail(demande);

            // retire la ligne de la table pending
            pendingList.remove(demande);
            tablePending.refresh();

            showInfo("Succès", "Demande " + demande.getReference() + " approuvée et email envoyé !");

        } catch (MessagingException e) {
            e.printStackTrace();
            showError("Erreur email", "La demande a été approuvée, mais l'email n'a pas pu être envoyé.\n\n" + e.getMessage());

        } catch (SQLException e) {
            e.printStackTrace();
            showError("Erreur SQL", "Impossible d'approuver la demande.\n\n" + e.getMessage());
        }
    }

    private void sendApprovalEmail(Demande demande) throws MessagingException {
        if (demande.getEmail() == null || demande.getEmail().isBlank()) {
            throw new MessagingException("L'email du client est vide.");
        }

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", String.valueOf(SMTP_PORT));
        props.put("mail.debug", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_USER, SMTP_PASS);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(demande.getEmail()));
        message.setSubject("Votre demande de voucher a été approuvée - " + demande.getReference());

        String htmlContent =
                "<h2>Demande approuvée</h2>"
                        + "<p>Bonjour <b>" + demande.getClient() + "</b>,</p>"
                        + "<p>Votre demande de voucher a été <b>approuvée</b>.</p>"
                        + "<p><b>Référence :</b> " + demande.getReference() + "</p>"
                        + "<p><b>Montant :</b> " + demande.getAmount() + "</p>"
                        + "<p>Merci de votre confiance.</p>"
                        + "<br>"
                        + "<p>Cordialement,<br>VMS Project</p>";

        message.setContent(htmlContent, "text/html; charset=UTF-8");

        Transport.send(message);
        System.out.println("Email d'approbation envoyé à : " + demande.getEmail());
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.show();
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(title);
        alert.setContentText(message);
        alert.show();
    }
}