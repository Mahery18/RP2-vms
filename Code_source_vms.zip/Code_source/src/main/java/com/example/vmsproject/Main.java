package com.example.vmsproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/dashboard.fxml"));

        // ➤ D’ABORD créer la scène
        Scene scene = new Scene(fxmlLoader.load());

        // ➤ Ensuite seulement ajouter le CSS
        scene.getStylesheets().add(getClass().getResource("/dashboard.css").toExternalForm());

        stage.setTitle("Connexion - VMS Project");
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
