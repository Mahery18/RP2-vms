package com.example.vmsproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;


import java.io.IOException;
import java.sql.*;
import java.util.Optional;

public class UsersController {

    @FXML
    private TableView<User> tableUsers;

    @FXML
    private TableColumn<User, Integer> colId;

    @FXML
    private TableColumn<User, String> colUsername;

    @FXML
    private TableColumn<User, String> colEmail;

    @FXML
    private TableColumn<User, Void> colActions; // Colonne pour boutons

    @FXML
    private TextField searchField;

    private ObservableList<User> usersList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));

        addButtonToTable(); // ajout des boutons dans la table
        loadUsers();
    }

    public void loadUsers() {
        usersList.clear();
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection conn = connectNow.getConnection();

        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT id, username, email, role FROM users");
            while (rs.next()) {
                usersList.add(new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getString("role")
                ));
            }
            tableUsers.setItems(usersList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void addUser() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Ajouter utilisateur");
        dialog.setHeaderText(null);
        dialog.setContentText("Nom d'utilisateur:");

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent() && !result.get().isEmpty()) {
            String username = result.get();

            TextInputDialog emailDialog = new TextInputDialog();
            emailDialog.setTitle("Ajouter utilisateur");
            emailDialog.setHeaderText(null);
            emailDialog.setContentText("Email:");
            Optional<String> emailResult = emailDialog.showAndWait();

            if (emailResult.isPresent() && !emailResult.get().isEmpty()) {
                String email = emailResult.get();

                // Mot de passe par défaut
                String defaultPassword = "123456";

                DatabaseConnection connectNow = new DatabaseConnection();
                Connection conn = connectNow.getConnection();

                try {
                    String query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.setString(1, username);
                    pst.setString(2, email);
                    pst.setString(3, defaultPassword);// mot de passe par défaut
                    pst.executeUpdate();

                    loadUsers(); // recharge le tableau après insertion
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void addButtonToTable() {
        Callback<TableColumn<User, Void>, TableCell<User, Void>> cellFactory = new Callback<>() {
            @Override
            public TableCell<User, Void> call(final TableColumn<User, Void> param) {
                return new TableCell<>() {
                    private final Button btnEdit = new Button("Modifier");
                    private final Button btnDelete = new Button("Supprimer");
                    private final HBox pane = new HBox(btnEdit, btnDelete);

                    {
                        pane.setSpacing(10);

                        btnEdit.setOnAction(event -> {
                            User user = getTableView().getItems().get(getIndex());
                            updateUser(user);
                        });

                        btnDelete.setOnAction(event -> {
                            User user = getTableView().getItems().get(getIndex());
                            deleteUser(user);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(pane);
                        }
                    }
                };
            }
        };

        colActions.setCellFactory(cellFactory);
    }

    private void updateUser(User user) {
        // Créer une fenêtre de dialogue personnalisée
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Modifier utilisateur");

        // Boutons OK et Cancel
        ButtonType okButtonType = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okButtonType, ButtonType.CANCEL);

        // Formulaire avec username et email
        TextField usernameField = new TextField(user.getUsername());
        TextField emailField = new TextField(user.getEmail());
        TextField roleField = new TextField(user.getRole());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Nom d'utilisateur:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Email:"), 0, 1);
        grid.add(emailField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        // Convertir les résultats en objet User
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButtonType) {
                return new User(user.getId(), usernameField.getText(), emailField.getText(), roleField.getText());
            }
            return null;
        });

        Optional<User> result = dialog.showAndWait();

        result.ifPresent(updatedUser -> {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection conn = connectNow.getConnection();
            try {
                String query = "UPDATE users SET username = ?, email = ? WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setString(1, updatedUser.getUsername());
                pst.setString(2, updatedUser.getEmail());
                pst.setInt(3, updatedUser.getId());
                pst.executeUpdate();
                loadUsers();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }


    private void deleteUser(User user) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Supprimer utilisateur");
        alert.setHeaderText(null);
        alert.setContentText("Voulez-vous vraiment supprimer " + user.getUsername() + " ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection conn = connectNow.getConnection();

            try {
                String query = "DELETE FROM users WHERE id = ?";
                PreparedStatement pst = conn.prepareStatement(query);
                pst.setInt(1, user.getId());
                pst.executeUpdate();

                loadUsers();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void goBack() {
        try {
            Stage stage = (Stage) tableUsers.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/home.fxml"));
            stage.setScene(new Scene(loader.load()));
            stage.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
