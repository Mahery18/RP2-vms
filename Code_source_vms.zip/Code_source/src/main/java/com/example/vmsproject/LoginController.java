package com.example.vmsproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label messageLabel;

    public void onLoginButtonClick(ActionEvent event) throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();

        DatabaseConnection connect = new DatabaseConnection();
        Connection conn = connect.getConnection();

        if (conn == null) {
            messageLabel.setText("Erreur : impossible de se connecter à la base !");
            return;
        }

        try {
            String sql = "SELECT id, username, email, role FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("id");
                String userName = rs.getString("username");
                String email = rs.getString("email");
                String role = rs.getString("role");

                User loggedUser = new User(userId, userName, email, role);

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/home.fxml"));
                Scene homeScene = new Scene(loader.load());
                HomeController homeCtrl = loader.getController();

                // ⚡ transmettre l’utilisateur
                homeCtrl.setCurrentUser(loggedUser);
                homeCtrl.setUserInfo(userName, role);

                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(homeScene);
                stage.setMaximized(true);
                stage.setTitle("Accueil - VMS Project");
                stage.show();
            } else {
                messageLabel.setText("Identifiants incorrects !");
            }

        } catch (Exception e) {
            messageLabel.setText("Erreur : " + e.getMessage());
            e.printStackTrace();
        }
    }
}

