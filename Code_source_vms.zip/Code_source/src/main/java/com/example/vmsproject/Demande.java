package com.example.vmsproject;

import java.time.LocalDate;

public class Demande {
    private String reference;
    private LocalDate date_created;
    private String client;
    private int quantite;
    private double amount;
    private LocalDate validity;
    private boolean fixedExpiry;
    private String status;
    private String recordedBy;
    private String approvedBy;
    private String paymentRemarks;
    private String email;

    public Demande(String reference, LocalDate date, String client, int quantite, double amount,
                   LocalDate validity, boolean fixedExpiry, String status,
                   String recordedBy, String approvedBy, String paymentRemarks, String email) {
        this.reference = reference;
        this.date_created = date;
        this.client = client;
        this.quantite = quantite;
        this.amount = amount;
        this.validity = validity;
        this.fixedExpiry = fixedExpiry;
        this.status = status;
        this.recordedBy = recordedBy;
        this.approvedBy = approvedBy;
        this.paymentRemarks = paymentRemarks;
        this.email = email;
    }

    // Getters et setters
    public String getReference() { return reference; }
    public LocalDate getDate_created() { return date_created; }
    public String getClient() { return client; }
    public int getQuantite() { return quantite; }
    public double getAmount() { return amount; }
    public LocalDate getValidity() { return validity; }
    public boolean isFixedExpiry() { return fixedExpiry; }
    public String getStatus() { return status; }
    public String getRecordedBy() { return recordedBy; }
    public String getApprovedBy() { return approvedBy; }
    public String getPaymentRemarks() { return paymentRemarks; }
    public String getEmail() { return email; }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }
}
