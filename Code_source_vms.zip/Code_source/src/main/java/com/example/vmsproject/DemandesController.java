package com.example.vmsproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.time.LocalDate;

public class DemandesController {

    @FXML private TableView<Demande> tableDemandes;
    @FXML private TableColumn<Demande, String> colReference;
    @FXML private TableColumn<Demande, LocalDate> colDate;
    @FXML private TableColumn<Demande, String> colClient;
    @FXML private TableColumn<Demande, Integer> colQuantite;
    @FXML private TableColumn<Demande, Double> colAmount;
    @FXML private TableColumn<Demande, LocalDate> colValidity;
    @FXML private TableColumn<Demande, Boolean> colFixedExpiry;
    @FXML private TableColumn<Demande, String> colStatus;
    @FXML private TableColumn<Demande, String> colRecordedBy;
    @FXML private TableColumn<Demande, String> colApprovedBy;
    @FXML private TableColumn<Demande, String> colPaymentRemarks;
    @FXML private TableColumn<Demande, String> colEmail;


    private ObservableList<Demande> demandesList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colReference.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date_created"));
        colClient.setCellValueFactory(new PropertyValueFactory<>("client"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colQuantite.setCellValueFactory(new PropertyValueFactory<>("quantite"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colValidity.setCellValueFactory(new PropertyValueFactory<>("validity"));
        colFixedExpiry.setCellValueFactory(new PropertyValueFactory<>("fixedExpiry"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colRecordedBy.setCellValueFactory(new PropertyValueFactory<>("recordedBy"));
        colApprovedBy.setCellValueFactory(new PropertyValueFactory<>("approvedBy"));
        colPaymentRemarks.setCellValueFactory(new PropertyValueFactory<>("paymentRemarks"));

        loadDemandes();
    }

    public void loadDemandes() {
        demandesList.clear();
        DatabaseConnection db = new DatabaseConnection();
        try (Connection conn = db.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM demande")) {

            while (rs.next()) {
                demandesList.add(new Demande(
                        rs.getString("reference"),
                        rs.getDate("date_created").toLocalDate(),
                        rs.getString("client"),
                        rs.getInt("quantite"),
                        rs.getDouble("amount"),
                        rs.getDate("validity_date") != null ? rs.getDate("validity_date").toLocalDate() : null,
                        rs.getBoolean("fixed_expiry"),
                        rs.getString("status"),
                        rs.getString("recorded_by"),
                        rs.getString("approved_by"),
                        rs.getString("payment_remarks"),
                        rs.getString("email")
                ));
            }
            tableDemandes.setItems(demandesList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addDemande(Demande demande) {
        demandesList.add(demande);
        tableDemandes.refresh();
    }
}
