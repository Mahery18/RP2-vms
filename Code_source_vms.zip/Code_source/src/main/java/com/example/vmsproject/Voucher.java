package com.example.vmsproject;

import java.time.LocalDate;

public class Voucher {
    private String voucherCode;
    private String demandeReference;
    private String client;
    private double amount;
    private LocalDate validityDate;
    private String status;
    private String qrPath;
    private String pdfPath;

    public Voucher(String voucherCode, String demandeReference, String client,
                   double amount, LocalDate validityDate, String status,
                   String qrPath, String pdfPath) {

        this.voucherCode = voucherCode;
        this.demandeReference = demandeReference;
        this.client = client;
        this.amount = amount;
        this.validityDate = validityDate;
        this.status = status;
        this.qrPath = qrPath;
        this.pdfPath = pdfPath;
    }

    // Constructeur pour afficher la liste sans QR/PDF
    public Voucher(String voucherCode, String demandeReference, String client,
                   double amount, LocalDate validityDate, String status) {
        this.voucherCode = voucherCode;
        this.demandeReference = demandeReference;
        this.client = client;
        this.amount = amount;
        this.validityDate = validityDate;
        this.status = status;
        this.qrPath = "";
        this.pdfPath = "";
    }

    public Voucher() {

    }


    // GETTERS
    public String getVoucherCode() { return voucherCode; }
    public String getDemandeReference() { return demandeReference; }
    public String getClient() { return client; }
    public double getAmount() { return amount; }
    public LocalDate getValidityDate() { return validityDate; }
    public String getStatus() { return status; }
    public String getQrPath() { return qrPath; }
    public String getPdfPath() { return pdfPath; }

    // SETTERS
    public void setVoucherCode(String voucherCode) { this.voucherCode = voucherCode; }
    public void setDemandeReference(String demandeReference) { this.demandeReference = demandeReference; }
    public void setClient(String client) { this.client = client; }
    public void setAmount(double amount) { this.amount = amount; }
    public void setValidityDate(LocalDate validityDate) { this.validityDate = validityDate; }
    public void setStatus(String status) { this.status = status; }
    public void setQrPath(String qrPath) { this.qrPath = qrPath; }
    public void setPdfPath(String pdfPath) { this.pdfPath = pdfPath; }
}
