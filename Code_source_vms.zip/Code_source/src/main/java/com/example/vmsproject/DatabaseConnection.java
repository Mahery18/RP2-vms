package com.example.vmsproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    public Connection getConnection() {
        Connection connection = null;
        try {
            String url = "jdbc:postgresql://postgresql-mahery.alwaysdata.net:5432/mahery_vms_db";
            String user = "mahery";
            String password = "alwaysdatamahery";

            connection = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Connexion réussie à la base de données !");
        } catch (Exception e) {
            System.out.println("❌ Erreur de connexion à la base : " + e.getMessage());
        }
        return connection;
    }
}
