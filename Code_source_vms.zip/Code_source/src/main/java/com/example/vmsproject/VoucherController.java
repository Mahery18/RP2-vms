package com.example.vmsproject;

import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.Properties;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

public class VoucherController {

    @FXML private TableView<Voucher> voucherTable;
    @FXML private TableColumn<Voucher, String> colCode;
    @FXML private TableColumn<Voucher, String> colDemande;
    @FXML private TableColumn<Voucher, String> colClient;
    @FXML private TableColumn<Voucher, Double> colAmount;
    @FXML private TableColumn<Voucher, LocalDate> colValidity;
    @FXML private TableColumn<Voucher, String> colStatus;
    @FXML private TableColumn<Voucher, Void> colViewPdf;

    @FXML private VBox formBox;
    @FXML private TextField demandeRefField;
    @FXML private TextField clientField;
    @FXML private TextField amountField;
    @FXML private DatePicker validityField;

    private String demandeRef;
    private String pdfPath;
    private String clientEmail;
    private int quantite;
    private double valeurUnitaire;
    private LocalDate emissionDate;
    private String demandeStatus;

    private final ObservableList<Voucher> voucherList = FXCollections.observableArrayList();
    private User currentUser;

    // Gmail
    private final String SMTP_HOST = "smtp.gmail.com";
    private final int SMTP_PORT = 587;
    private final String SMTP_USER = "maheryifalianaras@gmail.com";
    private final String SMTP_PASS = "jxkjtdcrpubwtolr";
    private final String FROM_EMAIL = "maheryifalianaras@gmail.com";

    // Logo
    private final String LOGO_PATH = "src/main/resources/images/logo.png";

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    @FXML
    public void initialize() {
        colCode.setCellValueFactory(new PropertyValueFactory<>("voucherCode"));
        colDemande.setCellValueFactory(new PropertyValueFactory<>("demandeReference"));
        colClient.setCellValueFactory(new PropertyValueFactory<>("client"));
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
        colValidity.setCellValueFactory(new PropertyValueFactory<>("validityDate"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        formBox.setVisible(false);
        voucherTable.setVisible(true);

        showVoucherListData();
        configureViewPdfColumn();
    }

    @FXML
    public void showForm() {
        formBox.setVisible(true);
        voucherTable.setVisible(false);
        clearForm();
    }

    @FXML
    public void showVoucherList() {
        formBox.setVisible(false);
        voucherTable.setVisible(true);
        showVoucherListData();
    }

    private void clearForm() {
        demandeRefField.clear();
        clientField.clear();
        amountField.clear();
        validityField.setValue(null);

        demandeRef = null;
        clientEmail = null;
        quantite = 0;
        valeurUnitaire = 0;
        emissionDate = null;
        demandeStatus = null;
        pdfPath = null;
    }

    private void configureViewPdfColumn() {
        colViewPdf.setCellFactory(tc -> new TableCell<>() {
            private final Button btn = new Button("Voir PDF");

            {
                btn.setOnAction(event -> {
                    Voucher voucher = getTableView().getItems().get(getIndex());
                    String currentPdfPath = voucher.getPdfPath();

                    if (currentPdfPath != null && !currentPdfPath.isEmpty()) {
                        try {
                            File pdfFile = new File(currentPdfPath);
                            if (pdfFile.exists()) {
                                Desktop.getDesktop().open(pdfFile);
                            } else {
                                new Alert(Alert.AlertType.ERROR,
                                        "Le fichier PDF n'existe pas : " + currentPdfPath).show();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            new Alert(Alert.AlertType.ERROR,
                                    "Erreur lors de l'ouverture du PDF").show();
                        }
                    } else {
                        new Alert(Alert.AlertType.WARNING,
                                "Aucun chemin PDF enregistré pour ce voucher").show();
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btn);
            }
        });
    }

    @FXML
    public void loadDemande() {
        String sql = """
                SELECT reference, client, email, quantite, valeur_unitaire, amount,
                       validity_date, date_created, status
                FROM demande
                WHERE reference = ?
                """;

        try (Connection conn = new DatabaseConnection().getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            demandeRef = demandeRefField.getText();

            if (demandeRef == null || demandeRef.isBlank()) {
                new Alert(Alert.AlertType.WARNING, "Veuillez saisir une référence de demande.").show();
                return;
            }

            pst.setString(1, demandeRef);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    clientField.setText(rs.getString("client"));
                    clientEmail = rs.getString("email");
                    quantite = rs.getInt("quantite");
                    valeurUnitaire = rs.getDouble("valeur_unitaire");
                    emissionDate = rs.getDate("date_created").toLocalDate();
                    demandeStatus = rs.getString("status");

                    amountField.setText(String.valueOf(valeurUnitaire));
                    validityField.setValue(rs.getDate("validity_date").toLocalDate());
                } else {
                    new Alert(Alert.AlertType.ERROR, "Demande non trouvée !").show();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Erreur lors du chargement de la demande.").show();
        }
    }

    private void generateQRCode(String text, String filePath) throws Exception {
        QRCodeWriter writer = new QRCodeWriter();
        BitMatrix matrix = writer.encode(text, BarcodeFormat.QR_CODE, 300, 300);
        BufferedImage img = new BufferedImage(300, 300, BufferedImage.TYPE_INT_RGB);

        for (int x = 0; x < 300; x++) {
            for (int y = 0; y < 300; y++) {
                img.setRGB(x, y, matrix.get(x, y) ? 0x000000 : 0xFFFFFF);
            }
        }

        ImageIO.write(img, "png", new File(filePath));
    }

    private void drawVoucherBlock(PDDocument document,
                                  PDPageContentStream content,
                                  float startX,
                                  float startY,
                                  float blockWidth,
                                  float blockHeight,
                                  String voucherCode,
                                  String client,
                                  String demandeReference,
                                  double valeurVoucher,
                                  LocalDate dateEmission,
                                  LocalDate dateExpiration,
                                  String statut,
                                  String qrPath) throws IOException {

        content.addRect(startX, startY - blockHeight, blockWidth, blockHeight);
        content.stroke();

        File logoFile = new File(LOGO_PATH);
        if (logoFile.exists()) {
            PDImageXObject logoImage = PDImageXObject.createFromFile(LOGO_PATH, document);
            content.drawImage(logoImage, startX + 15, startY - 55, 60, 35);
        }

        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 16);
        content.newLineAtOffset(startX + 90, startY - 30);
        content.showText("VOUCHER");
        content.endText();

        float textX = startX + 20;
        float textY = startY - 80;
        float lineGap = 18;

        writeLine(content, PDType1Font.HELVETICA_BOLD, 11, textX, textY,
                "Référence voucher : " + voucherCode);

        writeLine(content, PDType1Font.HELVETICA, 11, textX, textY - lineGap,
                "Valeur du voucher : " + valeurVoucher + " MGA");

        writeLine(content, PDType1Font.HELVETICA, 11, textX, textY - (2 * lineGap),
                "Date d'émission : " + dateEmission);

        writeLine(content, PDType1Font.HELVETICA, 11, textX, textY - (3 * lineGap),
                "Date d'expiration : " + dateExpiration);

        writeLine(content, PDType1Font.HELVETICA, 11, textX, textY - (4 * lineGap),
                "Référence client : " + demandeReference);

        writeLine(content, PDType1Font.HELVETICA, 11, textX, textY - (5 * lineGap),
                "Client : " + client);

        writeLine(content, PDType1Font.HELVETICA, 11, textX, textY - (6 * lineGap),
                "Statut : " + statut);

        PDImageXObject qrImage = PDImageXObject.createFromFile(qrPath, document);
        content.drawImage(qrImage, startX + blockWidth - 120, startY - 170, 90, 90);
    }

    private void writeLine(PDPageContentStream content,
                           PDType1Font font,
                           int fontSize,
                           float x,
                           float y,
                           String text) throws IOException {
        content.beginText();
        content.setFont(font, fontSize);
        content.newLineAtOffset(x, y);
        content.showText(text);
        content.endText();
    }

    private void generatePDF(String voucherCode,
                             String client,
                             String demandeReference,
                             double valeurVoucher,
                             LocalDate dateEmission,
                             LocalDate dateExpiration,
                             String statut,
                             String qrPath,
                             String outputPdfPath,
                             int nombreExemplaires) {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            float pageWidth = page.getMediaBox().getWidth();
            float pageHeight = page.getMediaBox().getHeight();

            float margin = 30;
            float blockWidth = pageWidth - (2 * margin);
            float blockHeight = 220;
            float gap = 20;

            PDPageContentStream content = new PDPageContentStream(document, page);

            int vouchersOnCurrentPage = 0;
            float currentY = pageHeight - margin;

            for (int i = 0; i < nombreExemplaires; i++) {
                if (vouchersOnCurrentPage == 3) {
                    content.close();
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    content = new PDPageContentStream(document, page);
                    currentY = page.getMediaBox().getHeight() - margin;
                    vouchersOnCurrentPage = 0;
                }

                drawVoucherBlock(
                        document,
                        content,
                        margin,
                        currentY,
                        blockWidth,
                        blockHeight,
                        voucherCode,
                        client,
                        demandeReference,
                        valeurVoucher,
                        dateEmission,
                        dateExpiration,
                        statut,
                        qrPath
                );

                currentY -= (blockHeight + gap);
                vouchersOnCurrentPage++;
            }

            content.close();
            document.save(outputPdfPath);

            System.out.println("PDF sauvegardé : " + outputPdfPath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void generateVoucher() {
        try {
            if (demandeRefField.getText() == null || demandeRefField.getText().isBlank()) {
                new Alert(Alert.AlertType.WARNING, "Veuillez charger une demande.").show();
                return;
            }

            if (quantite <= 0) {
                new Alert(Alert.AlertType.WARNING, "La quantité de vouchers est invalide.").show();
                return;
            }

            String voucherCode = "VCH-" + System.currentTimeMillis();
            String client = clientField.getText();
            LocalDate validity = validityField.getValue();

            String projectDir = System.getProperty("user.dir");

            // QR généré localement seulement
            String qrPath = projectDir + File.separator + "qr_" + voucherCode + ".png";
            generateQRCode(voucherCode, qrPath);

            // PDF généré localement
            pdfPath = projectDir + File.separator + "voucher_" + voucherCode + ".pdf";

            generatePDF(
                    voucherCode,
                    client,
                    demandeRef,
                    valeurUnitaire,
                    emissionDate != null ? emissionDate : LocalDate.now(),
                    validity,
                    "Unused",
                    qrPath,
                    pdfPath,
                    quantite
            );

            // SOLUTION 2 :
            // on n'insère PAS qr_path dans la base pour éviter l'erreur bytea
            String sql = """
                    INSERT INTO voucher
                    (voucher_code, demande_reference, client, amount, validity_date, status, pdf_path)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """;

            try (Connection conn = new DatabaseConnection().getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql)) {

                pst.setString(1, voucherCode);
                pst.setString(2, demandeRef);
                pst.setString(3, client);
                pst.setDouble(4, valeurUnitaire);
                pst.setDate(5, Date.valueOf(validity));
                pst.setString(6, "Unused");
                pst.setString(7, pdfPath);
                pst.executeUpdate();
            }

            Voucher voucher = new Voucher();
            voucher.setVoucherCode(voucherCode);
            voucher.setDemandeReference(demandeRef);
            voucher.setClient(client);
            voucher.setAmount(valeurUnitaire);
            voucher.setValidityDate(validity);
            voucher.setStatus("Unused");
            voucher.setQrPath(""); // pas stocké en base pour l'instant
            voucher.setPdfPath(pdfPath);

            sendVoucherEmail(voucher);

            new Alert(Alert.AlertType.INFORMATION,
                    "Voucher généré avec succès. PDF créé avec " + quantite + " exemplaires.").show();

            clearForm();
            showVoucherListData();
            showVoucherList();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Erreur lors de la génération du voucher.").show();
        }
    }

    private void showVoucherListData() {
        try {
            voucherList.clear();

            // On ne lit plus qr_path
            String sql = """
                    SELECT voucher_code, demande_reference, client, amount, validity_date, status, pdf_path
                    FROM voucher
                    ORDER BY created_at DESC
                    """;

            try (Connection conn = new DatabaseConnection().getConnection();
                 PreparedStatement pst = conn.prepareStatement(sql);
                 ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    Voucher v = new Voucher(
                            rs.getString("voucher_code"),
                            rs.getString("demande_reference"),
                            rs.getString("client"),
                            rs.getDouble("amount"),
                            rs.getDate("validity_date").toLocalDate(),
                            rs.getString("status"),
                            "", // qr_path ignoré pour le moment
                            rs.getString("pdf_path")
                    );
                    voucherList.add(v);
                }

                voucherTable.setItems(voucherList);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendVoucherEmail(Voucher voucher) {
        if (clientEmail == null || clientEmail.isBlank()) {
            new Alert(Alert.AlertType.ERROR, "Impossible d'envoyer l'email : email client introuvable.").show();
            return;
        }

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", String.valueOf(SMTP_PORT));

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SMTP_USER, SMTP_PASS);
            }
        });

        try {
            File file = new File(voucher.getPdfPath());
            if (!file.exists()) {
                System.err.println("Le fichier PDF n'existe pas : " + voucher.getPdfPath());
                return;
            }

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(clientEmail));
            message.setSubject("Votre voucher " + voucher.getVoucherCode());

            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(
                    "<h3>Bonjour " + voucher.getClient() + "</h3>" +
                            "<p>Veuillez trouver en pièce jointe votre voucher <b>" + voucher.getVoucherCode() + "</b>.</p>" +
                            "<p>Le PDF contient <b>" + quantite + "</b> exemplaires identiques du voucher.</p>",
                    "text/html; charset=UTF-8"
            );

            MimeBodyPart attachPart = new MimeBodyPart();
            attachPart.attachFile(file);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachPart);

            message.setContent(multipart);

            Transport.send(message);

            new Alert(Alert.AlertType.INFORMATION, "Email envoyé à " + clientEmail).show();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Erreur lors de l'envoi de l'email").show();
        }
    }

    @FXML
    private void goBack() {
        try {
            Stage stage = (Stage) formBox.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/home.fxml"));
            Parent root = loader.load();

            stage.setScene(new Scene(root));
            stage.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}