package com.example.vmsproject;

import java.time.LocalDateTime;

public class Redemption {
    private int id;
    private int voucherId;
    private String magasin;
    private int userId;
    private LocalDateTime redeemedAt;

    public Redemption(int id, int voucherId, String magasin, int userId, LocalDateTime redeemedAt) {
        this.id = id;
        this.voucherId = voucherId;
        this.magasin = magasin;
        this.userId = userId;
        this.redeemedAt = redeemedAt;
    }

    // Getters
    public int getId() { return id; }
    public int getVoucherId() { return voucherId; }
    public String getMagasin() { return magasin; }
    public int getUserId() { return userId; }
    public LocalDateTime getRedeemedAt() { return redeemedAt; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setVoucherId(int voucherId) { this.voucherId = voucherId; }
    public void setMagasin(String magasin) { this.magasin = magasin; }
    public void setUserId(int userId) { this.userId = userId; }
    public void setRedeemedAt(LocalDateTime redeemedAt) { this.redeemedAt = redeemedAt; }
}
