module com.example.vmsproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires javafx.graphics;

    requires jakarta.mail;
    requires jakarta.activation;
    requires com.google.zxing;
    requires org.apache.pdfbox;
    requires java.desktop;


    opens com.example.vmsproject to javafx.fxml;
    exports com.example.vmsproject;
}
